"""Nsight diagnostic: warm one real objective, then trace one repeated objective.

Profiling is diagnostic; end-to-end benchmark timings are collected separately.
"""
import argparse
import json
import time
from dataclasses import asdict
from pathlib import Path

from aster_hpo import Replication
from benchmarks.hedging import HedgingObjective, Market
from benchmarks import hedging_cuda

parser=argparse.ArgumentParser()
parser.add_argument('--backend',choices=('cuda','cuda_eager'),required=True)
parser.add_argument('--batch-paths',type=int,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
market=Market(batch_paths=args.batch_paths,evaluation_paths=2048 if args.batch_paths==128 else 32768)
config={'width':8,'learning_rate':0.03,'regularization':0.0001}
replication=Replication.create(31000,config,0,'search',True)
objective=HedgingObjective(market,backend=args.backend)
# Warm interpreter/context/JIT on this exact workload before the trace.
warm=objective.evaluate(config,replication)
hedging_cuda.synchronize()
cp=hedging_cuda._cupy()
cp.cuda.runtime.profilerStart()
cp.cuda.nvtx.RangePush('complete_objective')
start=time.perf_counter()
metrics=objective.evaluate(config,replication)
hedging_cuda.synchronize()
seconds=time.perf_counter()-start
cp.cuda.nvtx.RangePop()
cp.cuda.runtime.profilerStop()
assert metrics==warm
with args.output.open('x') as output:
 output.write(json.dumps({'backend':args.backend,'market':asdict(market),'config':config,
 'replication':asdict(replication),'metrics':metrics,'profiled_objective_seconds':seconds,
 'timing_scope':'warm diagnostic under profiler; not end-to-end benchmark evidence',
 'device':hedging_cuda.device_info()},indent=2)+'\n')
