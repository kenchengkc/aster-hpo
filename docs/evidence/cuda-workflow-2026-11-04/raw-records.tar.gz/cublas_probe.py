"""Library-only control: no project imports or custom accounting kernels."""
import gc
import cupy as cp


def control():
    left = cp.ones((7, 4, 2), dtype=cp.float64)
    right = cp.ones((2, 3), dtype=cp.float64)
    product = left @ right
    assert bool(cp.all(product == 2))
    cp.cuda.get_current_stream().synchronize()


control()
gc.collect()
cp.get_default_memory_pool().free_all_blocks()
cp.get_default_pinned_memory_pool().free_all_blocks()
print('Library-only batched matmul passed; pools explicitly released.')
