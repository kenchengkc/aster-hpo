# Synthetic scheduler diagnostics

Cheap known-mean objectives: these results do not establish practical speedup.
Regret is measured against the best configuration in each frozen pool.
Order permutations are sensitivity checks, not independent optimizer runs.

| Case | Shared | Order | Method | Runs | Failed | Mean replications | Mean regret |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: |
| additive | False | forward | full_budget | 20 | 0 | 324.0 | 0.0622599 |
| additive | False | forward | race | 20 | 0 | 140.1 | 0.0629682 |
| additive | False | reverse | full_budget | 20 | 0 | 324.0 | 0.0622599 |
| additive | False | reverse | race | 20 | 0 | 141.6 | 0.0629682 |
| additive | True | forward | full_budget | 20 | 0 | 324.0 | 0 |
| additive | True | forward | race | 20 | 0 | 60.0 | 0 |
| additive | True | reverse | full_budget | 20 | 0 | 324.0 | 0 |
| additive | True | reverse | race | 20 | 0 | 60.0 | 0 |
| heavy_tail | False | forward | full_budget | 20 | 0 | 324.0 | 0.0609448 |
| heavy_tail | False | forward | race | 20 | 0 | 151.8 | 0.0592031 |
| heavy_tail | False | reverse | full_budget | 20 | 0 | 324.0 | 0.0609448 |
| heavy_tail | False | reverse | race | 20 | 0 | 157.2 | 0.0592031 |
| heavy_tail | True | forward | full_budget | 20 | 0 | 324.0 | 0.00195351 |
| heavy_tail | True | forward | race | 20 | 0 | 97.8 | 0.00195351 |
| heavy_tail | True | reverse | full_budget | 20 | 0 | 324.0 | 0.00195351 |
| heavy_tail | True | reverse | race | 20 | 0 | 101.1 | 0.00195351 |
| heteroscedastic | False | forward | full_budget | 20 | 0 | 324.0 | 0.0475027 |
| heteroscedastic | False | forward | race | 20 | 0 | 157.8 | 0.045677 |
| heteroscedastic | False | reverse | full_budget | 20 | 0 | 324.0 | 0.0475027 |
| heteroscedastic | False | reverse | race | 20 | 0 | 159.3 | 0.045677 |
| heteroscedastic | True | forward | full_budget | 20 | 0 | 324.0 | 0.00580352 |
| heteroscedastic | True | forward | race | 20 | 0 | 101.4 | 0.00195351 |
| heteroscedastic | True | reverse | full_budget | 20 | 0 | 324.0 | 0.00580352 |
| heteroscedastic | True | reverse | race | 20 | 0 | 103.2 | 0.00195351 |
| near_ties | False | forward | full_budget | 20 | 0 | 324.0 | 0.0180384 |
| near_ties | False | forward | race | 20 | 0 | 185.1 | 0.0141043 |
| near_ties | False | reverse | full_budget | 20 | 0 | 324.0 | 0.0180384 |
| near_ties | False | reverse | race | 20 | 0 | 199.5 | 0.0145413 |
| near_ties | True | forward | full_budget | 20 | 0 | 324.0 | 0.0271313 |
| near_ties | True | forward | race | 20 | 0 | 197.1 | 0.0234671 |
| near_ties | True | reverse | full_budget | 20 | 0 | 324.0 | 0.0271313 |
| near_ties | True | reverse | race | 20 | 0 | 197.7 | 0.0234671 |

Positive paired differences in summary.json mean racing selected a worse
configuration than full-budget search. Failures remain null, not zero.
